<?php
session_start();
require('routeros_api.class.php');

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST['name'];
    $ip_bandwidth = $_POST['ip_bandwidth'];
    $download_limit = $_POST['download_limit'];
    $upload_limit = $_POST['upload_limit'];

    $API = new RouterosAPI();

    // Intentar conectar con MikroTik
    if ($API->connect('192.168.63.1', 'admin', 'admin')) {
        // Obtener la lista de colas simples
        $queues = $API->comm('/queue/simple/print');
        $queueId = null;

        // Buscar la cola correspondiente a la IP especificada
        foreach ($queues as $queue) {
            if (isset($queue['target']) && $queue['target'] === $ip_bandwidth) {
                $queueId = $queue['.id'];
                break;
            }
        }

        // Verificar si se encontró la cola
        if ($queueId !== null) {
            // Actualizar los límites de ancho de banda
            $API->comm('/queue/simple/add', [
                'name' => $name,
                'target' => $ip_bandwidth,
                'max-limit' => $download_limit . '/' . $upload_limit
            ]);
    
            $API->comm('/queue/simple/set', [
                '.id' => $queueId,
                'max-limit' => $download_limit . '/' . $upload_limit
                
            ]);
            $_SESSION['message'] = "Límite de ancho de banda actualizado exitosamente.";
            $_SESSION['alert_class'] = "alert-success";
        } else {
            $_SESSION['message'] = "No se encontró una cola de ancho de banda para la IP especificada.";
            $_SESSION['alert_class'] = "alert-danger";
        }

        $API->disconnect();
    } else {
        $_SESSION['message'] = "Error al conectar a MikroTik.";
        $_SESSION['alert_class'] = "alert-danger";
    }
}

header("location: templates/index.php");
exit();
?>
